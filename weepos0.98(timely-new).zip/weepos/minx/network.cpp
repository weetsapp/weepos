#include <iostream>

using namespace std;

class iplog{

public:

	int portNum;
	int vport;
	int mainPort;	
	
};


int main(){
iplog lplog;	
std::cout <<"Starting WeepOS NETWORK\t             [OK]"<<endl;

std::cout <<"Running WeepOS NETWORK\t             [OK]"<<endl;

std::cout <<"Starting WeepOS NETWORK interface\t             [OK]"<<endl;

system("localhost:8080");//starting...	
			
	lplog.portNum = 8080;//tweak the port address if you wish to
	lplog.vport = 10008;//for virtual port
	lplog.mainPort = 8080;
	
	std::cout << "Port running at default as: "<<lplog.mainPort<<endl;
}