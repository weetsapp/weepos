var network = {
				"signal" : true,
				"strength1" : 1,
				"strength2" : 2,
				"strebgth3" : 3,
				"proxy" : "0.0.0.0"
				}
