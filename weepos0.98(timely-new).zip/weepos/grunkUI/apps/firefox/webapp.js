//Firefox
var firefoxreq = 
{"appname" : "Firefox",
"launch_path" : "apps/firefox/browser.html",
"storage" : "sdcard",
"permission" : "read&write",
"version" : "1.0.2",
"notify_path" : "firefox/message.html",
"icon" : "apps/firefox/firefox.png"

}

var firefoxAuthor = {
				"developer" : "Mozilla",
				"email" : null,
				"phone" : null,
				"website" : "http://www.mozilla.org/firefox"
}





