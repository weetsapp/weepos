//Weets from Vemosoft
var weetsreq = 
{"appname" : "Weets",
"launch_path" : "apps/weets/start.html",
"storage" : "sdcard",
"permission" : "read-only",
"version" : "0.9.1",
"notify_path" : "weets/message.html",
"icon" : "apps/weets/weets.png"

}

var weetsAuth = {
				"developer" : "Vemosoft",
				"email" : null,
				"phone" : null,
				"website" : "http://www.vemosoft.com/weets"
}





