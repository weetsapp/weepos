//Facebook App
var facebookreq = {
			"appname" : "Facebook",
			"developer" : "Facebook.Inc",
			"launch_path" : "apps/facebook/login.html",
			"storage" : "sdcard",
			"permission" : "read-only",
			"version" : "1.0.2"	,
			"notify_path" : "message.html",
"icon" : "apps/facebook/facebook.png"
				}



var facebookAuthor = {
				"developer" : "Facebook.Inc",
				"email" : null,
				"phone" : null,
				"website" : "http://www.facebook.com/"
}
