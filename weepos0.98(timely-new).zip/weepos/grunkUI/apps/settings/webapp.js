//Settings
var settingsreq = 
{"appname" : "Settings",
"launch_path" : "apps/settings/settings.html",
"storage" : "sdcard",
"permission" : "read-only",
"version" : "0.9.1",
"notify_path" : "settings/message.html",
"icon" : "apps/settings/settings.png"

}

var settingsAuth = {
				"developer" : "Vemosoft",
				"email" : null,
				"phone" : null,
				"website" : "http://github.com/vemosoft/settings"
}





