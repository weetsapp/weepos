function vgameSettings(){
var gameSettings = document.getElementById("vgameSettings").alert("Game Settings")
}
